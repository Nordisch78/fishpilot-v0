FishPilot Web V0 – Oberried

INHALT
- index.html: Web-App
- bathymetry.geojson: aus der amtlichen Bathymetrie Brienzersee abgeleitete Tiefenlinien

LOKALER TEST
Die App sollte über einen kleinen Webserver geöffnet werden, nicht per Doppelklick auf index.html,
weil Browser lokale fetch()-Aufrufe blockieren können.

ONLINE (einfachster Weg)
1. Kostenloses GitHub-Konto anlegen/anmelden.
2. Neues öffentliches Repository z.B. fishpilot-v0 erstellen.
3. index.html und bathymetry.geojson hochladen.
4. Settings > Pages > Deploy from a branch > main / root.
5. GitHub erzeugt eine HTTPS-Webadresse, die auf iPad/iPhone funktioniert.

DATENQUELLE
Bathymetrie: Amt für Geoinformation Kanton Bern.
Basiskarte: OpenStreetMap-Mitwirkende.

HINWEIS
V0 ist ein Lern-/Machbarkeitsprototyp und enthält keine Fang- oder Rechtsberatung.
